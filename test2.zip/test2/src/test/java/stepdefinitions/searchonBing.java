package stepdefinitions;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pageObjects.BingHomepagePOB;

public class searchonBing {
	 
	WebDriver driver;
	
	
	/**
	 * This function will execute before each Test tag in testng.xml
	 * @param browser
	 * @throws Exception
	 */
	
	@Given("^Open a browser in Chrome as default$")
	public void open_a_browser_in_Chrome_as_default() throws Throwable {
		System.setProperty("webdriver.gecko.driver", "C:\\SravanthiSoftwares\\geckodriver.exe");
		driver = new FirefoxDriver();
	}
	
	@When("^Open a Search site and search for \"(.*?)\"$")
	public void open_a_Search_site_and_search_for(String searchText) throws Throwable {
		
		driver.get("https://www.google.com/");
		BingHomepagePOB binghome=PageFactory.initElements(driver, BingHomepagePOB.class);
		binghome.passtheValues(searchText);
		Thread.sleep(5000);
	}

	@Then("^In the search result page,assert for page title for exact match \"(.*?)\" & page url for contains \"(.*?)\"$")
	public void in_the_search_result_page_assert_for_page_title_for_exact_match_page_url_for_contains(String expectedTitle, String expectedvalue) throws Throwable {
		String actualpageTitle=driver.getTitle();
		System.out.println(actualpageTitle);
		Assert.assertEquals(expectedTitle, actualpageTitle);
		File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
		FileUtils.copyFile(srcFile, new File("D:\\SravanthiPersonal\\UHGProjectsWorkspace\\test2\\target\\screenshots\\tests1.png"));
		} catch (IOException e) {
		e.printStackTrace();
		}
		
	}

	@Then("^On successful validatin,go to the search results which contains the URL as \"(.*?)\" and perform a click operation$")
	public void on_successful_validatin_go_to_the_search_results_which_contains_the_URL_as_and_perform_a_click_operation(String expectedvalue) throws Throwable {
		String actualURL=driver.getCurrentUrl();
		if(actualURL.contains(expectedvalue)){
			Assert.assertTrue(true);
			File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			try {
			FileUtils.copyFile(srcFile, new File("D:\\SravanthiPersonal\\UHGProjectsWorkspace\\test2\\target\\screenshots\\tests2.png"));
			} catch (IOException e) {
			e.printStackTrace();
			}
		}
		else {
			Assert.assertFalse(false);
		}
		/*List<WebElement> allLinks = driver.findElements(By.tagName("a"));
		 
		 //Traversing through the list and printing its text along with link address
		 for(WebElement link:allLinks){
		 System.out.println(link.getText());
		 if(link.getText().contains(expectedvalue)){
			 link.click();
			 break;*/
		driver.navigate().to(expectedvalue);
		 Thread.sleep(10000);
			 }
	@Then("^In the next page,assert the page title as \"(.*?)\" and page url as \"(.*?)\"$")
	public void in_the_next_page_assert_the_page_title_as_and_page_url_as(String expectedTitl, String expectedUrl) throws Throwable {
	    
		String actualpageTitl=driver.getTitle();
		System.out.println(actualpageTitl);
		Assert.assertEquals(expectedTitl, actualpageTitl);
		File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
		FileUtils.copyFile(srcFile, new File("D:\\SravanthiPersonal\\UHGProjectsWorkspace\\test2\\target\\screenshots\\tests3.png"));
		} catch (IOException e) {
		e.printStackTrace();
		}
		String actualUrl=driver.getCurrentUrl();
		Assert.assertEquals(actualUrl, expectedUrl);
		File srcFile1 = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
		FileUtils.copyFile(srcFile1, new File("D:\\SravanthiPersonal\\UHGProjectsWorkspace\\test2\\target\\screenshots\\tests4.png"));
		} catch (IOException e) {
		e.printStackTrace();
		}
	}
	@Then("^After the assertion,click on the hamburger icon and select Services link via a mouse hover in the resulting leftside pane and click on Testing$")
	public void after_the_assertion_click_on_the_hamburger_icon_and_select_Services_link_via_a_mouse_hover_in_the_resulting_leftside_pane_and_click_on_Testing() throws Throwable {
		BingHomepagePOB binghome=PageFactory.initElements(driver, BingHomepagePOB.class);
		binghome.clickonHambergicon();
		binghome.mouseHoverClick();
	}
	

	@Then("^Once the next page is loaded assert the page URL as \"(.*?)\" and page title as \"(.*?)\"$")
	public void once_the_next_page_is_loaded_assert_the_page_URL_as_and_page_title_as(String expectedURl, String expectedTiTlE) throws Throwable {
		String actualUrL=driver.getCurrentUrl();
		Assert.assertEquals(expectedURl, actualUrL);
		String actualTiTle=driver.getTitle();
		System.out.println(actualTiTle);
		Assert.assertEquals(expectedTiTlE, actualTiTle);
		File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
		FileUtils.copyFile(srcFile, new File("D:\\SravanthiPersonal\\UHGProjectsWorkspace\\test2\\target\\screenshots\\test5.png"));
		} catch (IOException e) {
		e.printStackTrace();
		}
	   
	}


	

}
