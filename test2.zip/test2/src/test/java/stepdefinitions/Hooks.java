package stepdefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Parameters;

import cucumber.api.java.Before;

public class Hooks {
	/*public WebDriver driver;
@Parameters("browser")
@Before
public void BeforSteps(String browser) throws Exception{
	if(browser.equalsIgnoreCase("firefox")){
		//create firefox instance
			System.setProperty("webdriver.gecko.driver", "C:\\ParameshwarSoftwares\\geckodriver.exe");
			  
			driver = new FirefoxDriver();
		}
		//Check if parameter passed as 'chrome'
		else if(browser.equalsIgnoreCase("chrome")){
			//set path to chromedriver.exe
			System.setProperty("webdriver.chrome.driver","C:\\ParameshwarSoftwares\\chromedriver.exe");
			//create chrome instance
			driver = new ChromeDriver();
		}
				
		else{
			//If no browser passed throw exception
			throw new Exception("Browser is not correct");
		}
		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
}

*/}
