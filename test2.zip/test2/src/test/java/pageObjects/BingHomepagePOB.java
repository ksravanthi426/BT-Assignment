package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;





public class BingHomepagePOB {
  WebDriver driver;
 public BingHomepagePOB(WebDriver driver){
	 this.driver=driver;
 }
 @FindBy(name="q")
 WebElement searchfield;
 @FindBy(linkText="Infosys - Consulting | IT Services | Digital Transformation")
 WebElement title;
 @FindBy(xpath="//div[@class='burger']")
 WebElement icon;
 @FindBy(xpath="//*[text()='Services ']")
 WebElement elemen;
 @FindBy(xpath="//*[text()='Testing']")
 WebElement testing;
	public void passtheValues(String searchText){
		searchfield.sendKeys(searchText);
		searchfield.sendKeys(Keys.ENTER);
	}
	public void titleClick() throws InterruptedException{
		title.click();
		Thread.sleep(5000);
	}
	public void clickonHambergicon() throws InterruptedException{
		icon.click();
		Thread.sleep(5000);
	}
	public void mouseHoverClick() throws InterruptedException{
		Actions action=new Actions(driver);
		action.moveToElement(elemen).build().perform();
		Thread.sleep(2000);
		testing.click();
		Thread.sleep(5000);
	}
}
